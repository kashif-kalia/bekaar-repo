// Global Chart (Line Chart)
new Chart(document.getElementById('globalChart'), {
    type: 'line',
    data: {
      labels: ['2024', '2025', '2026', '2027', '2028', '2029'],
      datasets: [{
        label: 'Global Market (USD Billion)',
        data: [372.94, 391, 409, 427, 446, 473.72],
        borderColor: 'rgba(75, 192, 192, 1)',
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        tension: 0.4,
        fill: true
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: true },
        title: {
          display: true,
          text: "Global Market Projection"
        }
      }
    }
  });

  // India Chart (Bar Chart)
  new Chart(document.getElementById('indiaChart'), {
    type: 'bar',
    data: {
      labels: ['2023', '2025', '2027', '2029', '2031', '2032'],
      datasets: [{
        label: 'India Market (INR Billion)',
        data: [90215.8, 117000, 150000, 185000, 215000, 227059.9],
        backgroundColor: 'rgba(255, 159, 64, 0.6)',
        borderColor: 'rgba(255, 159, 64, 1)',
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: true },
        title: {
          display: true,
          text: "India Market Projection"
        }
      },
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });