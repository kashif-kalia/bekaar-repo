const imagePaths =[
  'img/Dinisha-Rai-lost-20-Kgs.png',
  'img/Jeni-Sinha-lost-18-kgs.png',
  'img/Kavya-Prabhakaran-lost-11-Kgs-and-healed-her-Diastasis-Recti.png',
  'img/Kayathri-S-list-18-Kgs-postpartum.png',
  'img/Monalisa-Dash-lost-7-Kgs.png',
  'img/Saloni-Tarang-lost-11-kgs-postpartum.png',
  'img/Shimoli-lost-9-Kgs-and-healed-her-Diastasis-Recti.png',
  'img/Vidhyadhari-lost-12-Kgs-and-belly-fat.png',
  'img/Mask group.jpg'
]
// Initialize the current image index
let currentImageIndex = 0;

// Function to change the image
function changeImage(direction) {
  // Update the index based on the direction
  currentImageIndex = (currentImageIndex + direction + imagePaths.length) % imagePaths.length;

  // Update the src of the displayed image
  const displayedImage = document.getElementById('displayedImage');
  displayedImage.src = imagePaths[currentImageIndex];
}


// Section 4: Image Slider
let currentIndex = 0;
const slider = document.getElementById("imageSlider");
const slides = Array.from(document.querySelectorAll(".slide")); // Convert NodeList to Array
const totalSlides = slides.length;

// Clone slides to create an infinite loop
slides.forEach((slide) => {
  const clone = slide.cloneNode(true);
  slider.appendChild(clone); // Append clone to the slider
});

// Update total slides after cloning
const updatedSlides = document.querySelectorAll(".slide");
const totalUpdatedSlides = updatedSlides.length;

let scrollInterval; // Declare globally so we can clear it later

function autoScroll() {
  const visibleSlides = window.innerWidth <= 780 ? 1 : 4;
  currentIndex++;
  updateSlider(visibleSlides);

  // Reset position when reaching the end
  if (currentIndex === totalSlides) {
    setTimeout(() => {
      slider.style.transition = "none"; // Disable animation for reset
      currentIndex = 0;
      slider.style.transform = `translateX(0)`;
    }, 500); // Matches the transition duration
  }
}

function updateSlider(visibleSlides) {
  slider.style.transform = `translateX(-${currentIndex * (100 / visibleSlides)}%)`;
  slider.style.transition = "transform 0.5s ease-in-out";
}

function startSliderIfNeeded() {
  clearInterval(scrollInterval); // Clear previous interval

  if (window.innerWidth > 780) {
    // Only start auto-scroll on desktop view
    scrollInterval = setInterval(autoScroll, 2000);
  }
}

// Run on load and when resizing
window.addEventListener("load", startSliderIfNeeded);
window.addEventListener("resize", startSliderIfNeeded);



// Section 6: Testimonial Slider
let currentTestimonial = 0;
const testimonials = [
  {
    image: 'img/Vidhyadhari-lost-12-Kgs-and-belly-fat.png',
    text: 'After 6 months postpartum, my belly didn’t reduce post pregnancy. While searching for Diastasis Recti solutions, I found Omama and joined their online program.\n\n     Arushi, my coach, created a personalized plan that supported my recovery and milk supply. With her encouragement, I lost 12 kg in 3 months, flattened my belly, reduced cravings, and felt stronger. Beyond weight loss, I became active, my back pain disappeared, and my confidence returned.',
    name: 'Vidhyadhari',
    // designation: 'lost 12 Kgs and belly fat'
  },
  {
    image: 'img/Kayathri-S-list-18-Kgs-postpartum.png',
    text: 'Postpartum, I weighed 72 kg with a 4+ finger DR gap and weak abdominal muscles, putting me at high risk of hernia. Thanks to Omama, my Diastasis is fully healed, my belly is flat, and I now weigh 56 kg—my weight before marriage!As a mom of two and an entrepreneur, I’m so grateful to Omama for helping me regain my health and confidence.',
    name: 'Kayathri S',
    // designation: 'Lost 16 kg and healed her Diastasis Recti'
  },
  {
    image: 'img/Jeni-Sinha-lost-18-kgs.png',
    text: 'After delivering my baby, I gradually gained a lot of weight—going from size S to L/XL. It was distressing to see the scale climb, and none of my old clothes fit anymore.Inspired by a friend’s transformation, I joined Omama and began my journey. In 9 months, I went from from 70 kg to 52 kg. I feel stronger, more flexible, and calmer now. I’m so grateful to Omama for guiding me through this journey.',
    name: 'Jeni Sinha',
    // designation: 'Lost 18 Kgs, Size XL to S'
  },
  {
    image: 'img/Monalisa-Dash-lost-7-Kgs.png',
    text: 'When I first came across Omama, I was skeptical about the results. But out of curiosity, I joined with the goal of losing belly fat and gaining energy. After delivery, I struggled with back pain, acidity, joint pain, sleepless nights, and low energy. My coach Anwesha explained everything so well that I could follow the plan, enjoy my favorite dishes, and do simple workouts (even when I was lazy!).',
    name: 'Monalisa Dash',
    // designation: 'Lost 7 Kgs and Belly Fat'
  },
  {
    image: 'img/Dinisha-Rai-lost-20-Kgs.png',
    text: 'Hi, I’m Dinisha, a working mom of a 7-month-old baby. I joined Omama after my doctor cleared me for workouts, three months postpartum.Starting at 67 kg after my C-section, I was determined to transform. My diet and workout plan was tailored to my preferences.In 4 months, I’ve lost 12 kg, my tummy is flat, and my body aches have reduced significantly.Thank you Omama, for making this journey so easy and enjoyable!',
    name: 'Dinisha Rai',
    // designation: 'Lost 12 Kgs, Body pain vanished'
  },
  {
    image: 'img/Kavya-Prabhakaran-lost-11-Kgs-and-healed-her-Diastasis-Recti.png',
    text: 'Hi, I’m Kavya, and I can’t thank Omama enough for the incredible progress I’ve made. I never thought I’d achieve this while still eating home-cooked South Indian meals like rice, idli, and dosa. Starting at 103 kg, I’ve lost 11 kg in 3 months and reduced my Diastasis Recti gap from 5 fingers to 2 fingers. I’m getting compliments from family and friends, and I still can’t believe the results!',
    name: 'Kavya Prabhakaran',
    // designation: 'Lost 11 Kgs and healed Diastasis Recti'
  },
  {
    image: 'img/Shimoli-lost-9-Kgs-and-healed-her-Diastasis-Recti.png',
    text: 'I’m Shimoli, and my journey with Omama has been both challenging and satisfying. I started at 68 kg, 2 months postpartum, with a 5-finger Diastasis Recti gap. I was eager to lose weight from day one, but my coach Ishav helped me understand that my body needed time to heal and that it’s a process, not a race. With her guidance, I lost 9 kg, healed my Diastasis Recti, and learned to balance food and workouts.!',
    name: 'Shimoli',
    // designation: 'Lost 9 Kgs and healed Diastasis Recti'
  },
  {
    image: 'img/Saloni-Tarang-lost-11-kgs-postpartum.png',
    text: 'I’m Saloni, and I’m grateful to Lekha from Omama for helping me transform in just 9 months. I started with doubts, but Lekha’s constant reassurance and support made all the difference. I lost 11 kg and now weigh what I did 3 years ago. What’s surprising is that I actually eat more than I did before and still enjoy all my favorite foods.',
    name: 'Saloni Tarang',
    // designation: 'Lost 11 Kgs and Belly Fat'
  }
  // Add more testimonials as needed
];


let currentslide = 0;
const testimonialcard = testimonials.length;
// const prevButton = document.querySelector('.prev');
// const nextButton = document.querySelector('.next');
const slideCount = document.querySelector('.slide-count');
const totalslideCount = document.querySelector('.totalslide-count')

function changeTestimonial(direction) {
  currentTestimonial = (currentTestimonial + direction + testimonials.length) % testimonials.length;
  document.querySelector('.testimonial-image').src = testimonials[currentTestimonial].image;
  document.querySelector('.testimonial-text').textContent = testimonials[currentTestimonial].text;
  document.querySelector('.client-name').textContent = testimonials[currentTestimonial].name;
  document.querySelector('.client-designation').textContent = testimonials[currentTestimonial].designation;
  if(direction == 1)
  {
    nextButtonEvent();
  }
  else if(direction == -1){
    previousButtonEvent();
  }
}

// Initialize the first testimonial
changeTestimonial(0);

// Section 7: Swiper Slider
const swiper = new Swiper(".mySwiper", {
  effect: "coverflow",
  loop: true,
  autoplay: {
    delay: 2000,
  },
  grabCursor: true,
  centeredSlides: true,
  slidesPerView: 2,
  spaceBetween: -50,
  coverflowEffect: {
    rotate: 0,
    stretch: 0,
    depth: 200,
    modifier: 1,
    slideShadows: true,
  },
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
});

// Custom navigation buttons for Swiper
document.addEventListener('DOMContentLoaded', () => {
  // Ensure swiper object is initialized
  if (typeof swiper === 'undefined') {
    console.error('Swiper is not initialized.');
    return;
  }

  // Get the button elements
  const nextBtn = document.querySelector('.custom-next-btn');
  const prevBtn = document.querySelector('.custom-prev-btn');
  const nextBtn1 = document.querySelector('.custom-next-btn1');
  const prevBtn1 = document.querySelector('.custom-prev-btn1');

  // Check if the elements exist before attaching event listeners
  if (nextBtn) {
    nextBtn.addEventListener('click', () => swiper.slideNext());
  } else {
    console.warn('.custom-next-btn element not found!');
  }

  if (prevBtn) {
    prevBtn.addEventListener('click', () => swiper.slidePrev());
  } else {
    console.warn('.custom-prev-btn element not found!');
  }

  if (nextBtn1) {
    nextBtn1.addEventListener('click', () => swiper.slideNext());
  } else {
    console.warn('.custom-next-btn1 element not found!');
  }

  if (prevBtn1) {
    prevBtn1.addEventListener('click', () => swiper.slidePrev());
  } else {
    console.warn('.custom-prev-btn1 element not found!');
  }
});



// For card count section6
function updateSlides() {
  // Update the slide count display
  slideCount.textContent = `0${currentslide + 1}`;
  totalslideCount.textContent=`/0${testimonialcard}`
}

function nextButtonEvent(){
  if (currentslide < testimonialcard - 1) {
    currentslide++;
  } else {
    currentslide = 0; // Loop back to first slide
  }
  updateSlides();
}

function previousButtonEvent(){
  if (currentslide > 0) {
    currentslide--;
  } else {
    currentslide = testimonialcard - 1; // Loop back to last slide
  }
  updateSlides();
}
updateSlides();


function closeNavbar() {
  const closeButton = document.querySelector(".btn-close");
  closeButton.click(); // Close button ko manually click trigger karega
}


  // updateSlides();
  function updateSwippers() {
    let slides = document.querySelectorAll(".carousel-slide");
    let lastIndex = slides.length - 1;

    slides.forEach((slide, index) => {
      slide.classList.remove("slide-prev", "slide-current", "slide-next");
    });

    slides[0].classList.add("slide-current");
    slides[1].classList.add("slide-next");
    slides[lastIndex].classList.add("slide-prev");
  }

  function moveNext() {
    let slides = document.querySelectorAll(".carousel-slide");
    let wrapper = document.querySelector(".carousel-wrapper");
    wrapper.appendChild(slides[0]);
    updateSwippers();
  }

  function movePrev() {
    let slides = document.querySelectorAll(".carousel-slide");
    let wrapper = document.querySelector(".carousel-wrapper");
    wrapper.prepend(slides[slides.length - 1]);
    updateSwippers();
  }

  document.querySelector(".carousel-next-btn").addEventListener("click", moveNext);
  document.querySelector(".carousel-prev-btn").addEventListener("click", movePrev);
  updateSwippers();
  

  

