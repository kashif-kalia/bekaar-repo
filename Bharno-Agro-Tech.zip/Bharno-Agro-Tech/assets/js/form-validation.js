function isEmptyOrSpaces(str) {
    return str === null || str.trim().length === 0;
}

function isValidEmail(email) {
    // Basic email regex
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function isValidPhone(phone) {
    // Only 10 digit numbers
    return /^[0-9]{10}$/.test(phone);
}

function validateContactForm() {
    let name = document.getElementById("contact-name").value;
    let email = document.getElementById("contact-email").value;
    let phone = document.getElementById("contact-phone").value;
    let message = document.getElementById("contact-message").value;

    if (isEmptyOrSpaces(name) || isEmptyOrSpaces(email) || isEmptyOrSpaces(phone) || isEmptyOrSpaces(message)) {
        alert("Please fill out all fields. Blank spaces are not allowed.");
        return false;
    }

    if (!isValidEmail(email)) {
        alert("Please enter a valid email address.");
        return false;
    }

    if (!isValidPhone(phone)) {
        alert("Please enter a valid 10-digit mobile number.");
        return false;
    }

    return true;
}

function validateFundForm() {
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let phone = document.getElementById("mobile").value;
    let message = document.getElementById("message").value;

    if (isEmptyOrSpaces(name) || isEmptyOrSpaces(email) || isEmptyOrSpaces(phone) || isEmptyOrSpaces(message)) {
        alert("Please fill out all fields. Blank spaces are not allowed.");
        return false;
    }

    if (!isValidEmail(email)) {
        alert("Please enter a valid email address.");
        return false;
    }

    if (!isValidPhone(phone)) {
        alert("Please enter a valid 10-digit mobile number.");
        return false;
    }

    return true;
}
