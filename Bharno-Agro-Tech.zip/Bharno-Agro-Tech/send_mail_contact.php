<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Using __DIR__ ensures it uses the absolute path
require __DIR__ . '/PHPMailer/src/PHPMailer.php';
require __DIR__ . '/PHPMailer/src/SMTP.php';
require __DIR__ . '/PHPMailer/src/Exception.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userEmail = filter_var($_POST['contact-email'], FILTER_SANITIZE_EMAIL);
    $userName = filter_var($_POST['contact-name'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $userMobile = filter_var($_POST['contact-phone'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $userMessage = filter_var($_POST['contact-message'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $formType = $_POST['form_type'] ?? 'unknown';

    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'bharnoagrotech@gmail.com';
        $mail->Password = 'vjuv zbcg pazt imqj';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Send Acknowledgment to user
        $mail->setFrom('bharnoagrotech@gmail.com', 'Bharno Agro Tech');
        $mail->addAddress($userEmail, $userName);
        $mail->isHTML(true);
        $mail->Subject = 'Thanks for showing interest in Our Vision!';
        $mail->Body = "
            <h3>Hello $userName,</h3>
            <p>Thanks for showing interest in sustainable agriculture.<br>We have got your query and will contact you soon!</p><br>
            <br><p>– Bharno Agro Tech Team</p>
            <p style='margin-top:20px; font-size: 14px; color: #666;'>If this mail landed in your spam folder, please mark it as <strong>Report as Not Spam</strong>. You may ignore this if already done.</p>";
            

        $mail->send();
        $mail->clearAddresses();

        // Notify the site owner
        $mail->addAddress('bharnoagrotech@gmail.com');
        $mail->Subject = 'New Contact Form Submission';
        $mail->Body = "
            <h3>New query via Contact Form</h3>
            <p><strong>Name:</strong> $userName</p>
            <p><strong>Email:</strong> $userEmail</p>
            <p><strong>Mobile:</strong> $userMobile</p>
            <p><strong>Message:</strong><br>$userMessage</p>";
        $mail->send();

        // Show JS alert to user
        echo "<script>window.location.href='contact.html?status=success';</script>";

    } catch (Exception $e) {
        echo "<script>window.location.href='contact.html?status=error';</script>";

    }
}
?>
